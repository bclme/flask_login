import config

config.salt = b'4\xa8y\x8e\xca\xfb\x7f\x8e\xd5\x97v\x14\xc7[Z\xd0' 
config.host = "localhost"
config.user = "root"
config.passwd = ""
config.database = "pop_app"

