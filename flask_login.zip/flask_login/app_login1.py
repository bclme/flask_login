import mysql.connector as mysql
import config
import functions
import hashlib

from flask import Flask, render_template, request, url_for, make_response
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
csrf = CSRFProtect(app)
csrf.init_app(app)
app.config['SECRET_KEY'] = 'SUPER SECRET KEY TEST'
crs_token = ''
credens =[]

@app.route('/', methods=['GET','POST']) 
def index():
    global credens, crs_token
    context = {
        'gh':'as' 
    }
    
    title='Login Screen'
    if len(credens) == 1:
         title='Dashboard'
         name1 = ''
         if request.method == 'POST' :
           name1 = request.form['name']
         if name1 == 'logout':
             title='Login Screen'
             credens = []
             resp =make_response(render_template('index.html', title=title, **context))
             resp.headers.add('Content-Security-Policy','default-src \'self\'')
             return resp
             
         else:
           resp =make_response(render_template('pages/dashboard.html',  crs_token= crs_token, credens=credens, title=title, **context))
           resp.headers.add('Content-Security-Policy','default-src \'self\'')
           return resp
    if request.method == 'POST' :      
      if len(credens) == 0:  
        #connection = sqlite3.connect("userdata1.db")
        #cursor = connection.cursor()

        try:
          db = mysql.connect(
             host = config.host,
             user = config.user,
             passwd = config.passwd,
             database = config.database,
             raise_on_warnings= True
          )
          cursor = db.cursor()
          t1 = request.form['username']
          t2 = request.form['password'] # Appl3Tr33.456
          #salt = b'4\xa8y\x8e\xca\xfb\x7f\x8e\xd5\x97v\x14\xc7[Z\xd0'
          #print(t2)
          t2 = hashlib.pbkdf2_hmac("sha256", t2.encode(), config.salt, 100000)
        
          t1 = repr(str(t1))
          t2 = repr(str(t2))
          print(t2)
          print(t1)
          query = "SELECT * FROM tbusr where username = %s and userpassword  = %s" %(t1, t2)
        
           
          cursor.execute(query)
          records = cursor.fetchall()   
        except mysql.Error as e:
            #self.statusBar.showMessage("Error in MySql check connection", 5000)
            return None
        
        #name = request.form['username']
        #password = request.form['password']
        crs_token = request.form['csrf_token']
        
        #query = "SELECT name,password FROM users where name='" + name + "' and password='" + password + "'"
        #cursor.execute(query)
        #results = cursor.fetchall()
        if len(records) == 0:
            print("Incorrect credentials provided!")
        else:
            credens = [{
                'name': t1
                }]
            title='Dashboard'
            
            resp =make_response(render_template('pages/dashboard.html',  crs_token = crs_token, credens=credens, title=title, **context))
            resp.headers.add('Content-Security-Policy','default-src \'self\'') 
            return resp

      else:
         title='Login Screen'
         credens = []
         resp =make_response(render_template('index.html', title=title, **context))
         resp.headers.add('Content-Security-Policy','default-src \'self\'')
         return resp
    resp =make_response(render_template('index.html', title=title, **context))
    resp.headers.add('Content-Security-Policy','default-src \'self\'')
    return resp
 


if __name__ == '__main__': 
    app.run(debug=True) 
