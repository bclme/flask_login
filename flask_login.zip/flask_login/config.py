
salt = ""
host = "localhost"
user = "root"
passwd = ""
database = "pop_app"


